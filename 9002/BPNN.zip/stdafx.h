#pragma once
#include "targetver.h"
#define WIN32_LEAN_AND_MEAN
#define MT4_EXPFUNC __declspec(dllexport)
#include <windows.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <time.h>
using namespace std;